# Installation des visuels

1. Copier le dossier `assets/brand/` à la racine du dépôt.
2. Copier le contenu de `README-header.md` au début du README principal. Les chemins sont prévus pour un README à la racine.
3. Utiliser `social-preview.png` comme image de partage du dépôt lorsque l’interface GitHub le permet.
4. Utiliser `avatar.png` pour un profil ou une organisation associés au projet si souhaité. Le kit ne crée pas d’avatar individuel de dépôt.
5. Conserver `BRAND.md` et `brand-tokens.css` comme références pour les futurs visuels.

La balise `picture` de l’en-tête choisit une bannière selon le thème du lecteur. Le fichier clair sert de repli. Les fichiers sont fournis à leur résolution native ; leur affichage dans le README est redimensionné par le navigateur.

L’aperçu social emploie une composition au ratio 2:1. Les dimensions exactes de tous les PNG figurent dans `ASSETS.txt`.

Le contenu technique complet du README — installation, configuration, outils MCP, exemples et licence — reste à compléter selon le code réel du projet.
