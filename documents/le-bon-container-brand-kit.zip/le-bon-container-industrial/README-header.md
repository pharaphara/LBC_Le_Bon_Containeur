<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/brand/banner-dark.png">
  <source media="(prefers-color-scheme: light)" srcset="assets/brand/banner-light.png">
  <img alt="Le Bon Container — Il a la tête de l’emploi. MCP server, headed Chromium, Docker." src="assets/brand/banner-light.png" width="100%">
</picture>

# Le Bon Container

**Il a la tête de l’emploi.**  
*A browser with a head. A container with a purpose.*

### Français

Un conteneur Docker pour explorer les annonces Leboncoin avec des agents IA, via un serveur MCP et Chromium en mode graphique.

### English

A Docker container for crawling Leboncoin with AI agents, through an MCP server and Chromium running in headed mode.

---

Projet indépendant, non affilié à Leboncoin.  
Independent project, not affiliated with Leboncoin.

<!-- Compléter avec installation, configuration, outils MCP, exemples et licence selon le projet réel. -->
